//
//  MenuView.swift
//  MacAProject
//
//  Created by 머성이 on 7/3/24.
//

import UIKit

class MenuView: UIView {

}
